var ngApp = angular.module('myNgValidator', []);
